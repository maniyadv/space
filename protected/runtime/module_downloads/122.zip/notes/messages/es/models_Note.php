<?php
return array (
  'Could not get note content!' => '¡No se pudo obtener el contenido de la nota!',
  'Could not get note users!' => '¡No se pudo obtener los usuarios de la nota!',
  'Note' => 'Nota',
);
