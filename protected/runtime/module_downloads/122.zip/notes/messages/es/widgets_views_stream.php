<?php
return array (
  'Back to stream' => 'Volver a actividad',
  'No notes found which matches your current filter(s)!' => '¡No se encontraron notas que coincidan con tu filtro actual!',
  'There are no notes yet!' => '¡No hay notas todavía!',
);
