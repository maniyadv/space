<?php
return array (
  'Title of your new note' => 'Título de tu nueva nota',
);
