<?php
return array (
  'Open note' => 'Abrir nota',
);
