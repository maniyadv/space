<?php
return array (
  'API Connection successful!' => '',
  'Back to modules' => 'Terug naar modules',
  'Could not connect to API!' => '',
  'Current Status:' => 'Huidige status:',
  'Notes Module Configuration' => 'Notitie module configuratie',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => '',
  'Save & Test' => 'Bewaar & Test',
  'The notes module needs a etherpad server up and running!' => '',
);
