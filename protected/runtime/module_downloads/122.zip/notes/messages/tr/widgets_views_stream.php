<?php
return array (
  'Back to stream' => 'Geri dön',
  'No notes found which matches your current filter(s)!' => 'Geçerli filtreyle eşleşen hiç bir not bulunamadı!',
  'There are no notes yet!' => 'Henüz not girilmemiş!',
);
