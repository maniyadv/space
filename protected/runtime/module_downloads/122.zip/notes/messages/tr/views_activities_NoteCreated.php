<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} kullanıcı {noteName} yeni bir not yazdı.',
);
