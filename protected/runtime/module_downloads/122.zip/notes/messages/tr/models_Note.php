<?php
return array (
  'Could not get note content!' => 'İçerik notları alınamadı!',
  'Could not get note users!' => 'Kullanıcı notları alınamadı!',
  'Note' => 'Not',
);
