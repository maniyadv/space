<?php
return array (
  'API Connection successful!' => 'API bağlantısı başarılı!',
  'Back to modules' => 'Modüllere dön',
  'Could not connect to API!' => 'API bağlantısı sağlanamadı!',
  'Current Status:' => 'Şu an ki durum:',
  'Notes Module Configuration' => 'Not modül yapılandırma',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Lütfen "/protected/modules/notes/docs/install.txt" altındaki modül dökümanını okuyun. ',
  'Save & Test' => 'Kaydet ve test et',
  'The notes module needs a etherpad server up and running!' => 'Not modülü için çalışan bir etherpad sunucusuna ihtiyaç var!',
);
