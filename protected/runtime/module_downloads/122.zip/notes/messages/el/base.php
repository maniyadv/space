<?php
return array (
  'Notes' => 'Σημειώσεις',
);
