<?php
return array (
  'Notes' => 'Noter',
);
