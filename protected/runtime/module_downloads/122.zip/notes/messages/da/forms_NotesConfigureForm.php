<?php
return array (
  'Etherpad API Key' => 'Etherpad API Nøgle',
  'URL to Etherpad' => 'URL til Etherpad',
);
