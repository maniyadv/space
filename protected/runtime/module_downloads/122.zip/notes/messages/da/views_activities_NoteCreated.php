<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} Oprettede et nyt notat {noteName}.',
);
