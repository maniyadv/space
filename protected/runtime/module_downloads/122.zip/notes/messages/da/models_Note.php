<?php
return array (
  'Could not get note content!' => 'Kunne ikke indhente note indhold!',
  'Could not get note users!' => 'Kunne ikke indhente note brugere!',
  'Note' => 'Note',
);
