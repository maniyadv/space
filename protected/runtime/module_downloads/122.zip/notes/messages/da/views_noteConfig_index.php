<?php
return array (
  'API Connection successful!' => 'API Forbindelse udført!',
  'Back to modules' => 'Tilbage til moduler',
  'Could not connect to API!' => 'Kunne ikke forbinde til API!',
  'Current Status:' => 'Nuværende Status:',
  'Notes Module Configuration' => 'Notes Modul Konfiguration',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Venligst læs modul dokumentationen i /protected/modules/notes/docs/install.txt for yderligere detaljer!',
  'Save & Test' => 'Gem & Test',
  'The notes module needs a etherpad server up and running!' => 'Note modulet skal bruge etherpad server kørende!',
);
