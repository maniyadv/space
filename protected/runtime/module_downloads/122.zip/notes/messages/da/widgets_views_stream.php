<?php
return array (
  'Back to stream' => 'Tilbage til stream',
  'No notes found which matches your current filter(s)!' => 'Ingen noter blev fundet med dit nuværende filter!',
  'There are no notes yet!' => 'Der er ingen notater endnu!',
);
