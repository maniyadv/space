<?php
return array (
  'Save and close' => '',
);
