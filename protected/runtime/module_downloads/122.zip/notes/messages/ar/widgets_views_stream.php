<?php
return array (
  'Back to stream' => '',
  'No notes found which matches your current filter(s)!' => '',
  'There are no notes yet!' => '',
);
