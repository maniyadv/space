<?php
return array (
  'Could not get note content!' => '',
  'Could not get note users!' => '',
  'Note' => '',
);
