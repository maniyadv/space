<?php
return array (
  'Back to stream' => 'Powrót do strumienia',
  'No notes found which matches your current filter(s)!' => 'Nie znaleziono notatek pasujących do obecnego filtru(-ów)!',
  'There are no notes yet!' => 'Nie ma jeszcze notatek! ',
);
