<?php
return array (
  'Could not get note content!' => 'Nie można wczytać zawartości notatki! ',
  'Could not get note users!' => 'Nie można wczytać użytkowników notatki! ',
  'Note' => 'Notatka ',
);
