<?php
return array (
  'Etherpad API Key' => 'Klucz API Etherpad',
  'URL to Etherpad' => 'URL do Etherpad',
);
