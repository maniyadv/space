<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} utworzył nową notatkę i przydzielił ciebie. ',
);
