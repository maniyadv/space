<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} یک یادداشت جدید ایجاد کرد و به شما اختصاص داد.',
);
