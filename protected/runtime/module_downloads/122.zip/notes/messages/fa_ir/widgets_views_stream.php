<?php
return array (
  'Back to stream' => 'بازگشت به جریان',
  'No notes found which matches your current filter(s)!' => 'هیچ یادداشتی که با فیلتر کنونی شما هم‌خوانی داشته‌باشد پیدا نشد!',
  'There are no notes yet!' => 'هنوز هیچ یادداشتی وجود ندارد!',
);
