<?php
return array (
  'Could not get note content!' => 'محتوای یادداشت گرفته‌نشد!',
  'Could not get note users!' => 'کاربران یادداشت گرفته‌نشد!',
  'Note' => 'یادداشت',
);
