<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName} روی یادداشت {noteName} کار کرده‌است.',
);
