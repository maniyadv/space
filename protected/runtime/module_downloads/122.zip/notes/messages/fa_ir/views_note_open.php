<?php
return array (
  'Save and close' => 'ذخیره و بستن',
);
