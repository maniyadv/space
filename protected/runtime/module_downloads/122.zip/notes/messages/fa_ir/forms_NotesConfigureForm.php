<?php
return array (
  'Etherpad API Key' => 'کلید Etherpad API',
  'URL to Etherpad' => 'آدرس به Etherpad API',
);
