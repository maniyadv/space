<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} روی یادداشت {spaceName} کار کرده‌است.',
);
