<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} یادداشت جدید {noteName} را ایجادکرد.',
);
