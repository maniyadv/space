<?php
return array (
  'Back to stream' => 'Atgal į srautą',
  'No notes found which matches your current filter(s)!' => 'Nerasta pastabų, kurios atitiktų Jūsų pasirinktą filtrą (-us)!',
  'There are no notes yet!' => 'Kol kas nėra pastabų!',
);
