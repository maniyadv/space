<?php
return array (
  'Title of your new note' => 'Naujos pastabos pavadinimas',
);
