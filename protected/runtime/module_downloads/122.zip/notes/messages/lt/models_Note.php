<?php
return array (
  'Could not get note content!' => 'Nerastas pastabos turinys!',
  'Could not get note users!' => 'Nerasti pastabos vartotojai!',
  'Note' => 'Pastaba',
);
