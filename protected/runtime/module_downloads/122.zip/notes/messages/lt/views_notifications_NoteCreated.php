<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} sukūrė naują pastabą ir priskyrė Jus.',
);
