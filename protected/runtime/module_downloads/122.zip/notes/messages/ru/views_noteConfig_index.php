<?php
return array (
  'API Connection successful!' => 'API соединение прошло успешно!',
  'Back to modules' => 'Назад к модулям',
  'Could not connect to API!' => 'Не удалось соединение с API!',
  'Current Status:' => 'Текущий статус:',
  'Notes Module Configuration' => 'Конфигурация модуля Заметок',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Пожалуйста прочитайте докуметацию к модулю /protected/modules/notes/docs/install.txt для получения дополнительной информации',
  'Save & Test' => 'Сохранить и протестировать',
  'The notes module needs a etherpad server up and running!' => 'Для модуля заметок необходим работающий сервер Etherpad',
);
