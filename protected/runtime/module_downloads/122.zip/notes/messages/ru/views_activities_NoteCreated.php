<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} создал новую заметку {noteName}.',
);
