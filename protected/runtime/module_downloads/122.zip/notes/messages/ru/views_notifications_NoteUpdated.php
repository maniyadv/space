<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} работал над заметкой {spaceName}.',
);
