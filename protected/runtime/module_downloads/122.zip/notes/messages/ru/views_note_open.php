<?php
return array (
  'Save and close' => 'Сохранить и закрыть',
);
