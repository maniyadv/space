<?php
return array (
  'Could not get note content!' => 'Не могу прочить содерджимое заметки!',
  'Could not get note users!' => 'Не могу получить пользователей заметки!',
  'Note' => 'Заметка',
);
