<?php
return array (
  'Back to stream' => 'Вернуться в поток',
  'No notes found which matches your current filter(s)!' => 'Не найдено заметок в соответствии с установленными фильтрами!',
  'There are no notes yet!' => 'Еще нет заметок!',
);
