<?php
return array (
  'Open note' => 'Открыть заметку',
);
