<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName}  создал новую заметку и назначил для вас',
);
