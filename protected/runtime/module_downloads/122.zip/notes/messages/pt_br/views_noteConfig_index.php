<?php
return array (
  'API Connection successful!' => 'API - Conexão bem sucedida!',
  'Back to modules' => 'Voltar aos módulos',
  'Could not connect to API!' => 'Não foi possível conectar-se a API!',
  'Current Status:' => 'Status atual:',
  'Notes Module Configuration' => 'Configuração do Módulo de Notas',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Por favor, leia a documentação do módulo em  protected/modules/notes/docs/install.txt para mais detalhes!',
  'Save & Test' => 'Salvar & Testar',
  'The notes module needs a etherpad server up and running!' => 'O módulo de notas precisa de um servidor EtherPad Up e executando!',
);
