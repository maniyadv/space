<?php
return array (
  'Title of your new note' => 'Título da sua nova nota',
);
