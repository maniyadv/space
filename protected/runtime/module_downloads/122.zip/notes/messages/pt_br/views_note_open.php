<?php
return array (
  'Save and close' => 'Salvar e fechar',
);
