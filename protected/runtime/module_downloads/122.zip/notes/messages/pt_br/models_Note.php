<?php
return array (
  'Could not get note content!' => 'Não foi possível obter o conteúdo da nota!',
  'Could not get note users!' => 'Não foi possível obter os usuários de nota!',
  'Note' => 'Nota',
);
