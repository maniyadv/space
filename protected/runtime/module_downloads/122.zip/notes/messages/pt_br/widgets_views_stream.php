<?php
return array (
  'Back to stream' => 'Voltar para stream',
  'No notes found which matches your current filter(s)!' => 'Nenhuma anotação foi encontrada que coincide com o seu(s) filtro(s) atual(ais)',
  'There are no notes yet!' => 'Ainda não existem notas!',
);
