<?php
return array (
  'Etherpad API Key' => 'Chave da API do Etherpad',
  'URL to Etherpad' => 'URL para Etherpad',
);
