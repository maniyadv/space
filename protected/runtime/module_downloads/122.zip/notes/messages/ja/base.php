<?php
return array (
  'Notes' => 'ノート',
);
