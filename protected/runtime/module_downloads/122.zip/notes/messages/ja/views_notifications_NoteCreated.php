<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName}さんは新しいノートを作成し、あなた参加を設定しました。',
);
