<?php
return array (
  'Open note' => 'ノートを開く',
);
