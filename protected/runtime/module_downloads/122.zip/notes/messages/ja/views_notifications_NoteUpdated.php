<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName}さんは、ノート {spaceName} の加筆訂正をしました。',
);
