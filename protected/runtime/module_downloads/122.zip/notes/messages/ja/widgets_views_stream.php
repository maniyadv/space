<?php
return array (
  'Back to stream' => 'ストリームに戻る',
  'No notes found which matches your current filter(s)!' => '現在のフィルタに一致するノートは見つかりませんでした！',
  'There are no notes yet!' => 'まだノートはありません！',
);
