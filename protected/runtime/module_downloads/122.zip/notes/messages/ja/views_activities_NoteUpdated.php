<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName}さんはノート{noteName}に加筆編集しました。',
);
