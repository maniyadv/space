<?php
return array (
  'API Connection successful!' => 'APIの接続に成功！',
  'Back to modules' => 'モジュールへ戻る',
  'Could not connect to API!' => 'APIに接続できませんでした！',
  'Current Status:' => '現在のステータス：',
  'Notes Module Configuration' => 'ノートモジュールの設定',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => '詳細については、下の/protected/modules/notes/docs/install.txtモジュールのドキュメントを読んでください！',
  'Save & Test' => '保存＆テスト',
  'The notes module needs a etherpad server up and running!' => 'ノートモジュールはEtherPadサーバーが稼働中である必要があります！',
);
