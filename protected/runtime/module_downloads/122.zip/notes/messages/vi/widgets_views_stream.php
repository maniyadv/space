<?php
return array (
  'Back to stream' => 'Quay lại nhóm ',
  'No notes found which matches your current filter(s)!' => '',
  'There are no notes yet!' => '',
);
