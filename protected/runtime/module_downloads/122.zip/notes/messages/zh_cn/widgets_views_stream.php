<?php
return array (
  'Back to stream' => '返回动态',
  'No notes found which matches your current filter(s)!' => '',
  'There are no notes yet!' => '',
);
