<?php
return array (
  'Could not get note content!' => 'Impossibile ottenere il contenuto delle note!',
  'Could not get note users!' => 'Impossibile ottenere gli utenti delle note!',
  'Note' => 'Nota',
);
