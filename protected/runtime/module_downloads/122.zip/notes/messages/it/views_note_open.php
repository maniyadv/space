<?php
return array (
  'Save and close' => 'Salva e chiudi',
);
