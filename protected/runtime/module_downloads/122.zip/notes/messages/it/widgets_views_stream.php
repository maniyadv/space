<?php
return array (
  'Back to stream' => 'Indietro allo stream',
  'No notes found which matches your current filter(s)!' => 'Non c\'è alcuna nota che rispetta il tuo filtro corrente!',
  'There are no notes yet!' => 'Non c\'è ancora nessuna nota!',
);
