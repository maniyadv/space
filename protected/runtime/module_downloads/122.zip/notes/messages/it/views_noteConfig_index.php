<?php
return array (
  'API Connection successful!' => 'Connessione API avvenuta con successo!',
  'Back to modules' => 'Indietro ai moduli',
  'Could not connect to API!' => 'Non posso effettuare la connessione API',
  'Current Status:' => 'Stato corrente:',
  'Notes Module Configuration' => 'Configurazione del modulo delle note',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Per favore leggi il modulo della documentazione in /protected/modules/notes/docs/install.txt per maggiori dettagli!',
  'Save & Test' => 'Salva e testa',
  'The notes module needs a etherpad server up and running!' => 'Il modulo delle note ha bisogno di un serve su cui è attivo etherpad!',
);
