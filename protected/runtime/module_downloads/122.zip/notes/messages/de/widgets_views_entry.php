<?php
return array (
  'Open note' => 'Öffne Notiz',
);
