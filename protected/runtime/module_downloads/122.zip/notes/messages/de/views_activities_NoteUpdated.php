<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName} hat die Notiz »{noteName}« bearbeitet.',
);
