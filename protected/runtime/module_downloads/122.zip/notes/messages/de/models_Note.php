<?php
return array (
  'Could not get note content!' => 'Konnte den Inhalt der Notiz nicht laden!',
  'Could not get note users!' => 'Konnte die Nutzer der Notiz nicht laden!',
  'Note' => 'Notiz',
);
