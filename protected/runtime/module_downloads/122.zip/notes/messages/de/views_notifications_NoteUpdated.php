<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} hat die Notiz im Space {spaceName} bearbeitet.',
);
