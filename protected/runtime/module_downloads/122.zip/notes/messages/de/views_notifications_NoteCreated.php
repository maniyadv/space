<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} hat eine neue Notiz erzeugt und dich hinzugefügt.',
);
