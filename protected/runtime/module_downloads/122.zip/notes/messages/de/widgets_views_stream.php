<?php
return array (
  'Back to stream' => 'Zurück zur Übersicht',
  'No notes found which matches your current filter(s)!' => 'Keine Notiz zu den Filtereinstellungen gefunden!',
  'There are no notes yet!' => 'Keine Notizen vorhanden!',
);
