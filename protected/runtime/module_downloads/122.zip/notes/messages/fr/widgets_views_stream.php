<?php
return array (
  'Back to stream' => 'Retour au flux',
  'No notes found which matches your current filter(s)!' => 'Aucun note n\'a été trouvée à partir de votre filtre courant!',
  'There are no notes yet!' => 'Il n\'y a pas encore de note!',
);
