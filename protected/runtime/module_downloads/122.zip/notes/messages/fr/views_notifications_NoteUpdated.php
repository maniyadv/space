<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} a travaillé sur la note {spaceName}.',
);
