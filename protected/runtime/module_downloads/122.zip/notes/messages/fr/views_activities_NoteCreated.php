<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} a créé une nouvelle note {noteName}.',
);
