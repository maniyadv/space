<?php
return array (
  'Title of your new note' => 'Titre de votre nouvelle note',
);
