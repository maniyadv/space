<?php
return array (
  'Open note' => 'Note ouverte',
);
