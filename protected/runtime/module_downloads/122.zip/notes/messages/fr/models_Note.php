<?php
return array (
  'Could not get note content!' => 'Impossible d\'obtenir le contenu de la note!',
  'Could not get note users!' => 'Impossible d\'obtenir les notes d\'utilisateurs!',
  'Note' => 'Note',
);
