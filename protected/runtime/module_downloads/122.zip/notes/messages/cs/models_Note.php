<?php
return array (
  'Could not get note content!' => 'Nebylo možné získat obsah poznámky!',
  'Could not get note users!' => 'Nebylo možné získat seznam uživatelů poznámky!',
  'Note' => 'Poznámka',
);
