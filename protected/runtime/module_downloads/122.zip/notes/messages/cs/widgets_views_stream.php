<?php
return array (
  'Back to stream' => 'Zpět na přehled příspěvků',
  'No notes found which matches your current filter(s)!' => 'Nebyla nalezena žádná poznámka, která odpovídá vašemu vyhledávání.',
  'There are no notes yet!' => 'Zatím zde nejsou žádné poznámky!',
);
