<?php
return array (
  'Back to stream' => 'Torna a l\'activitat',
  'No notes found which matches your current filter(s)!' => '',
  'There are no notes yet!' => '',
);
