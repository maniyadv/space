Tasks Module
==============

Simple task manager for spaces.


For more  informations visit:
<https://github.com/humhub/humhub-modules-tasks>
