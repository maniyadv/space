<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  'Back to stream' => '@@Torna al fil social@@',
  'No tasks found which matches your current filter(s)!' => '@@No s\'han trobat tasques que coincideixin amb els criteris!@@',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Encara no hi ha tasques!</b><br>Sigues el primer en crear-ne una...',
  'Assigned to me' => 'Assignat a mi',
  'Created by me' => 'Creat per mi',
  'Creation time' => 'Data de creació',
  'Filter' => 'Filtre',
  'Last update' => 'Data d\'actualització',
  'Nobody assigned' => 'Cap persona assignada',
  'Sorting' => 'Ordena',
  'State is finished' => 'Finalitzades',
  'State is open' => 'Obertes',
);
