<?php
return array (
  'Tasks' => 'Tasques',
);
