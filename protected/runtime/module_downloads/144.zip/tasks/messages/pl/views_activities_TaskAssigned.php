<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} dołączył do {task}.',
);
