<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  'Back to stream' => '@@Powrót do strumienia@@',
  'No tasks found which matches your current filter(s)!' => '@@Nie znaleziono zadań pasujących do obecnego filtru(-ów)!@@',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Jeszcze nie ma żadnych zadań!</b><br>Bądź pierwszym który je utworzy...',
  'Assigned to me' => 'Dodał mnie',
  'Created by me' => 'Utworzone przeze mnie ',
  'Creation time' => 'Czas utworzenia',
  'Filter' => 'Filtr',
  'Last update' => 'Ostatnia aktualizacja',
  'Nobody assigned' => 'Nikt nie dołączył',
  'Sorting' => 'Sortowanie',
  'State is finished' => 'Stan zakończony',
  'State is open' => 'Stan otwarty ',
);
