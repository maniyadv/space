<?php
return array (
  'Tasks' => 'Zadania ',
);
