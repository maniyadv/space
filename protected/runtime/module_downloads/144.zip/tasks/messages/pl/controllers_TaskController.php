<?php
return array (
  'Could not access task!' => 'Nie można uzyskać dostępu do zadań! ',
);
