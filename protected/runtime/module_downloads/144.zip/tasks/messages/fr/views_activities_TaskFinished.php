<?php
return array (
  '{userName} finished task {task}.' => '{userName} a terminé la tâche {task}.',
);
