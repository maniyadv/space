<?php
return array (
  'Tasks' => 'Tâches',
);
