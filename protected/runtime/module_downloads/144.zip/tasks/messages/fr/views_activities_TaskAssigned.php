<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} a été assigné à la tâche {task}.',
);
