<?php
return array (
  'Could not access task!' => 'Accès aux Tâches refusés !',
);
