<?php
return array (
  '{userName} created a new task {task}.' => '{userName} a créé une nouvelle tâche : {task}.',
);
