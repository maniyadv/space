<?php
return array (
  'Back to stream' => '@@Retour au Stream@@',
  'No tasks found which matches your current filter(s)!' => '@@Pas de tâches trouvées avec ces filtres@@',
  '<b>There are no tasks yet!</b>' => '<b>Il n\'y a aucune tâche actuellement</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Il n\'y a pas de tâches ici !</b><br>Soyez le premier à en créer une...',
  'Assigned to me' => 'Me l\'assigner',
  'Created by me' => 'Mes créations',
  'Creation time' => 'Date de création',
  'Filter' => 'Filtre',
  'Last update' => 'Dernière mise à jour',
  'Nobody assigned' => 'Personne d\'assigné',
  'Sorting' => 'Trier',
  'State is finished' => 'État est Fini',
  'State is open' => 'État est Ouvert',
);
