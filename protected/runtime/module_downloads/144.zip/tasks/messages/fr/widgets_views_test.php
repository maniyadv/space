<?php
return array (
  'Do you want to handle this task?' => 'Voulez-vous traiter cette tâche ?',
  'I do it!' => 'Je vais le faire !',
);
