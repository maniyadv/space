<?php
return array (
  '{userName} finished task {task}.' => '{userName} a fini {task}.',
);
