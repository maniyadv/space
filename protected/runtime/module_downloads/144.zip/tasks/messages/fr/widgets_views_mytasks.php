<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Mes</strong> tâches',
  'From space: ' => 'De l\'espace :',
);
