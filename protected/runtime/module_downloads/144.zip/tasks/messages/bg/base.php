<?php
return array (
  'Tasks' => 'Задачи',
);
