<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Criar</strong> nova tarefa',
  '<strong>Edit</strong> task' => '<strong>Editar</strong> tarefa',
  'Assign users' => 'Designar usuários',
  'Assign users to this task' => 'Designar usuários para esta tarefa',
  'Cancel' => 'Cancelar',
  'Deadline' => 'Prazo',
  'Deadline for this task?' => 'Prazo para esta tarefa?',
  'Preassign user(s) for this task.' => 'Pré-designar usuário(s) para esta tarefa.',
  'Save' => 'Salvar',
  'Task description' => 'Descrição da tarefa',
  'What is to do?' => 'O que é para fazer?',
);
