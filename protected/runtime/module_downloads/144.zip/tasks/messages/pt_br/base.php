<?php
return array (
  'Tasks' => 'Tarefas',
);
