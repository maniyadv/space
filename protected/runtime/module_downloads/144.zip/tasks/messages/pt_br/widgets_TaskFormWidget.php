<?php
return array (
  'Create' => 'Criar',
);
