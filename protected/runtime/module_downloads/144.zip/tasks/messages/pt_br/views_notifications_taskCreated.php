<?php
return array (
  '{userName} created a new task {task}.' => '{userName} criou a nova tarefa {task}.',
);
