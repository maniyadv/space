<?php
return array (
  '{userName} created task {task}.' => '{userName} görev oluşturdu {task}.',
);
