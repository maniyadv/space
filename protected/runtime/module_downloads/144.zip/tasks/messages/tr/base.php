<?php
return array (
  'Tasks' => 'Görevler',
);
