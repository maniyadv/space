<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Benim</strong> görevlerim',
  'From space: ' => 'Mekandan:',
);
