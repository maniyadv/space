<?php
return array (
  'Create' => 'Oluştur',
);
