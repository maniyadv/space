<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} size bir görev atadı {task}.',
);
