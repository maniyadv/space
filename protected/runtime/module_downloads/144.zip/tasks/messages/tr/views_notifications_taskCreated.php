<?php
return array (
  '{userName} created a new task {task}.' => '{userName} yeni bir görev oluşturdu {task}.',
);
