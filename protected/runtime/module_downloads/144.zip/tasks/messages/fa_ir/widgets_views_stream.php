<?php
return array (
  'Back to stream' => '@@بازگشت به جریان@@',
  'No tasks found which matches your current filter(s)!' => '@@هیچ کاری پیدا نشد که با فیلتر(های) کنونی شما هم‌خوانی داشته‌باشد!@@',
  '<b>There are no tasks yet!</b>' => '<b>هنوز هیچ کاری موجود نیست!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>هنوز هیچ کاری موجود نیست!</b> <br> اولین نفر باشید و یک کار را شروع کنید . . .',
  'Assigned to me' => 'سپرده‌شده به من',
  'Created by me' => 'ایجادشده توسط من',
  'Creation time' => 'زمان ایجاد',
  'Filter' => 'فیلتر',
  'Last update' => 'آخرین به‌روزرسانی',
  'Nobody assigned' => 'به هیچ‌کس سپرده‌نشده',
  'Sorting' => 'مرتب‌سازی',
  'State is finished' => 'مرحله به پایان رسیده‌است',
  'State is open' => 'مرحله باز است',
);
