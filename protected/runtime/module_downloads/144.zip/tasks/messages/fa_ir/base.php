<?php
return array (
  'Tasks' => 'کارها',
);
