<?php
return array (
  'Tasks' => 'Tareas',
);
