<?php
return array (
  'Tasks' => 'Užduotys',
);
