<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Mano</strong> užduotys',
  'From space: ' => 'Iš erdvės:',
);
