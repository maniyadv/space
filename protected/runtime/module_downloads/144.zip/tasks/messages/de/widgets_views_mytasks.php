<?php
return array (
  '<strong>My</strong> tasks' => '<strong>Meine</strong> Aufgaben',
  'From space: ' => 'Aus Space: ',
);
