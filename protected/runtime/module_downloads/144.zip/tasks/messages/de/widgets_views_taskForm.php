<?php
return array (
  'Assign users to this task' => 'User zu dieser Aufgabe zuordnen',
  'Deadline for this task?' => 'Deadline für diese Aufgabe?',
  'Preassign user(s) for this task.' => '',
  'What to do?' => 'Was ist zu tun?',
);
