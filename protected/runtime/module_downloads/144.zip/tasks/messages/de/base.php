<?php
return array (
  'Tasks' => 'Aufgaben',
);
