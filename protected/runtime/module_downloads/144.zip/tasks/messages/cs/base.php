<?php
return array (
  'Tasks' => 'Úkoly',
);
