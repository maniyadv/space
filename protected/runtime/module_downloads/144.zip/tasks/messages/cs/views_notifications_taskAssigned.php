<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} vás přiřadil(a) k úkolu {task}.',
);
