<?php
return array (
  'Create' => 'Vytvořit',
);
