<?php
return array (
  'Tasks' => 'Attività',
);
