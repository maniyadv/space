<?php
return array (
  '{userName} finished task {task}.' => '{userName} ha completato il task {task}.',
);
