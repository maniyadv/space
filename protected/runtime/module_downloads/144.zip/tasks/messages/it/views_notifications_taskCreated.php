<?php
return array (
  '{userName} created a new task {task}.' => '{userName} ha creato il nuovo task {task}.',
);
