<?php
return array (
  '<strong>My</strong> tasks' => 'I <strong>Miei</strong> task',
  'From space: ' => 'Dallo space:',
);
