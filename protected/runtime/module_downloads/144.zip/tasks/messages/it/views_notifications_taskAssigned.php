<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} ha assegnato a te il task {task}.',
);
