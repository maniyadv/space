<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} ha assegnato il task {task}.',
);
