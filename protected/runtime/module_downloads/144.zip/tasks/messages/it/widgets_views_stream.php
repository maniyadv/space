<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  'Back to stream' => '@@Indietro allo stream@@',
  'No tasks found which matches your current filter(s)!' => '@@Nessun task trovato che rispetta il tuo corrente filtro!@@',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Non ci sono ancora task!</b><br>Come prima cosa creane uno...',
  'Assigned to me' => 'Assegnato a me',
  'Created by me' => 'Creato da me',
  'Creation time' => 'Data di creazione',
  'Filter' => 'Filtro',
  'Last update' => 'Ultimo aggiornamento',
  'Nobody assigned' => 'Assegnato a nessuno',
  'Sorting' => 'Ordinamento',
  'State is finished' => 'Lo stato è completato',
  'State is open' => 'Lo stato è aperto',
);
