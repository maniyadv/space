<?php
return array (
  'Tasks' => 'Taken',
);
