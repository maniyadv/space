<?php
return array (
  'Could not access task!' => 'Не удалось получить доступ к задаче!',
);
