<?php
return array (
  'Create' => 'Создать',
);
