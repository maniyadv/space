<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Создать</strong> новую задача',
  '<strong>Edit</strong> task' => '<strong>Редактировать</strong> задачу',
  'Assign users' => 'Назначить пользователей',
  'Assign users to this task' => 'Назначить пользователей для этой задачи',
  'Cancel' => 'Отменить',
  'Deadline' => 'Крайний срок',
  'Deadline for this task?' => 'Срок для решения этой задачи?',
  'Preassign user(s) for this task.' => 'Назначенный пользователь (и) для этой задачи.',
  'Save' => 'Сохранить',
  'Task description' => 'Описание задачи',
  'What is to do?' => 'Что делать?',
);
