<?php
return array (
  'Tasks' => 'タスク',
);
