<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '',
  'Assigned to me' => '',
  'Created by me' => '',
  'Filter' => '',
  'Nobody assigned' => '',
  'State is finished' => '',
  'State is open' => '',
  'Back to stream' => '@@ストリームに戻る@@',
  'No tasks found which matches your current filter(s)!' => '@@@@',
  'Creation time' => '作成時間',
  'Last update' => '最後のアップデート',
  'Sorting' => '並べ替え',
);
