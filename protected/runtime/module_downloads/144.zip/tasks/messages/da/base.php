<?php
return array (
  'Tasks' => 'Opgaver',
);
